import java.util.ArrayList;

public class Node {
    Node left, right;
    ArrayList<Node> duplicates;
    private String key;
    private float value;

    /**
     * Class Constructor specifying key and value of Node.
     */
    Node(String key, float value) {
        this.duplicates = new ArrayList<>();
        this.key = key;
        this.value = value;
        left = right = null;
    }

    public Node getLeft() {
        return left;
    }

    public void setLeft(Node left) {
        this.left = left;
    }

    public Node getRight() {
        return right;
    }

    public void setRight(Node right) {
        this.right = right;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }
}